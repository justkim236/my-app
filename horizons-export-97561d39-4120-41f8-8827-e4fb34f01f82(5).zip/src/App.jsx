import React, { useState, useEffect } from 'react';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import MathFormulaSection from '@/components/MathFormulaSection';
import ExerciseVideoSection from '@/components/ExerciseVideoSection';
import TraitEvaluationSection from '@/components/TraitEvaluationSection';
import FeedbackSection from '@/components/FeedbackSection';
import HealthConsentModal from '@/components/HealthConsentModal';
import DataDisplayTabs from '@/components/DataDisplayTabs';
import Homepage from '@/components/Homepage'; // Import Homepage
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PlusSquare, Dumbbell, Sigma, Brain, FileText, UserCheck, Home } from 'lucide-react'; // Added Home icon

const App = () => {
  const { toast } = useToast();
  const [showHomepage, setShowHomepage] = useState(true); // State to control homepage visibility
  const [consentGiven, setConsentGiven] = useState(false);
  const [refreshDataKey, setRefreshDataKey] = useState(0);
  const [activeTab, setActiveTab] = useState("homepage"); // Default to homepage

  useEffect(() => {
    const storedConsent = localStorage.getItem('healthConsentGiven');
    if (storedConsent === 'true') {
      setConsentGiven(true);
      // If consent is given, decide if homepage should still be shown or go to app
      const hasSeenHomepage = localStorage.getItem('hasSeenHomepage');
      if (hasSeenHomepage === 'true') {
        setShowHomepage(false);
        setActiveTab("inputs"); // Default to inputs or last active tab
      } else {
        setShowHomepage(true); // Show homepage if consent given but homepage not seen
        setActiveTab("homepage");
      }
    } else {
      // No consent, always start with homepage (which will lead to consent modal)
      setShowHomepage(true);
      setActiveTab("homepage");
    }
  }, []);

  const handleEnterApp = () => {
    setShowHomepage(false); 
    if (!consentGiven) {
      // Consent modal will appear
      // setActiveTab will be handled by consent flow or remain default if consent is skipped/handled elsewhere
    } else {
      setActiveTab("inputs"); // Or last active tab
      localStorage.setItem('hasSeenHomepage', 'true');
    }
  };
  
  const navigateToHomepage = () => {
    setShowHomepage(true);
    setActiveTab("homepage"); 
  };

  const handleConsent = () => {
    localStorage.setItem('healthConsentGiven', 'true');
    setConsentGiven(true);
    setShowHomepage(false); // Move to app after consent
    setActiveTab("inputs"); 
    localStorage.setItem('hasSeenHomepage', 'true'); 
    toast({
      title: "Consent Given",
      description: "Thank you for agreeing to the health and safety terms.",
      variant: "default",
    });
  };

  const triggerDataRefresh = () => {
    setRefreshDataKey(prevKey => prevKey + 1);
  };

  const handleListBasedDataSubmission = (title, description, storageKey, newData, resetFormCallback) => {
    try {
      let existingData = JSON.parse(localStorage.getItem(storageKey)) || [];
      if (!Array.isArray(existingData)) {
        existingData = [];
      }
      
      const updatedData = [...existingData, newData];
      localStorage.setItem(storageKey, JSON.stringify(updatedData));
      
      toast({
        title: title,
        description: description,
        variant: "default",
      });
      triggerDataRefresh();
    } catch (error) {
      console.error("Error saving to localStorage:", error);
      toast({
        title: "Storage Error",
        description: "Could not save data. Your browser's local storage might be full or disabled.",
        variant: "destructive",
      });
    }
    if (resetFormCallback) resetFormCallback();
  };
  
  const handleSingleEntryDataSubmission = (title, description, storageKey, data, resetFormCallback) => {
    try {
      localStorage.setItem(storageKey, JSON.stringify(data));
      toast({
        title: title,
        description: description,
        variant: "default",
      });
      triggerDataRefresh(); 
    } catch (error)
    {
      console.error("Error saving to localStorage:", error);
      toast({
        title: "Storage Error",
        description: "Could not save data. Your browser's local storage might be full or disabled.",
        variant: "destructive",
      });
    }
    if (resetFormCallback) resetFormCallback();
  };

  if (showHomepage) {
     return <Homepage onEnterApp={handleEnterApp} />;
  }

  if (!consentGiven) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-tan-light via-tan to-tan-dark text-brand-secondary flex flex-col items-center justify-center p-4">
        <HealthConsentModal onAgree={handleConsent} />
        <Toaster />
      </div>
    );
  }
  
  const tabItems = [
    { value: "homepage", label: "Home", icon: Home, color: "gray" },
    { value: "inputs", label: "Inputs", icon: PlusSquare, color: "brand-primary" },
    { value: "videos", label: "Exercises", icon: Dumbbell, color: "brand-accent" },
    { value: "formulas", label: "Formulas", icon: Sigma, color: "orange" },
    { value: "evaluation", label: "Self-Eval", icon: UserCheck, color: "yellow" },
    { value: "reflections", label: "Reflections", icon: Brain, color: "lime" },
    { value: "feedback", label: "Feedback", icon: FileText, color: "green" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-tan-light via-tan to-tan-dark text-brand-secondary flex flex-col">
      <Header />
      <Tabs 
        value={activeTab} 
        onValueChange={(value) => {
          if (value === "homepage") {
            navigateToHomepage();
          } else {
            setShowHomepage(false); 
            setActiveTab(value);
          }
        }} 
        className="flex flex-col flex-grow"
      >
        <main className="container mx-auto py-12 px-4 flex-grow mb-20">
          <TabsContent value="inputs" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <MathFormulaSection onSubmit={handleListBasedDataSubmission} />
              <ExerciseVideoSection onSubmit={handleListBasedDataSubmission} />
              <TraitEvaluationSection onSubmit={handleSingleEntryDataSubmission} />
            </div>
          </TabsContent>
          <TabsContent value="videos" className="mt-0">
            <DataDisplayTabs type="videos" storageKey="exerciseVideoEntries" title="Uploaded Exercise Videos" refreshKey={refreshDataKey} />
          </TabsContent>
          <TabsContent value="formulas" className="mt-0">
            <DataDisplayTabs type="formulas" storageKey="mathFormulaEntries" title="Uploaded Math Formulas" refreshKey={refreshDataKey} />
          </TabsContent>
          <TabsContent value="evaluation" className="mt-0">
             <DataDisplayTabs type="trait_evaluation" storageKey="traitEvaluationEntry" title="Self-Evaluations" refreshKey={refreshDataKey} isSingleEntry={true} />
          </TabsContent>
          <TabsContent value="reflections" className="mt-0">
            <DataDisplayTabs type="reflections" storageKey="feedbackEntries" title="Workout Reflections" refreshKey={refreshDataKey} filterType="reflection" />
          </TabsContent>
          <TabsContent value="feedback" className="mt-0">
            <FeedbackSection onSubmit={handleListBasedDataSubmission} />
            <DataDisplayTabs type="reflections" storageKey="feedbackEntries" title="Submitted Feedback & Questions" refreshKey={refreshDataKey} filterTypeExclude="reflection" />
          </TabsContent>
        </main>

        <TabsList className="fixed bottom-0 left-0 right-0 grid w-full grid-cols-7 h-auto p-2 bg-tan-light/90 backdrop-blur-md border-t border-tan-dark shadow-t-lg z-50">
          {tabItems.map(item => (
            <TabsTrigger
              key={item.value}
              value={item.value}
              className={`flex flex-col items-center justify-center p-2 rounded-md transition-colors duration-200 
                          data-[state=active]:bg-${item.color === "brand-primary" || item.color === "brand-accent" || item.color === "gray" ? item.color : `${item.color}-500`} 
                          data-[state=active]:text-${item.color === "brand-primary" || item.color === "brand-accent" ? 'white' : (item.color === "gray" ? 'brand-secondary' : `${item.color}-foreground`)}
                          hover:bg-${item.color === "brand-primary" || item.color === "brand-accent" || item.color === "gray" ? (item.color === "gray" ? 'neutral-300' : item.color+'/80') : `${item.color}-400/30`} 
                          text-neutral-600 data-[state=inactive]:hover:text-${item.color === "brand-primary" || item.color === "brand-accent" || item.color === "gray" ? (item.color === "gray" ? 'brand-secondary' : item.color) : `${item.color}-600`}`}
            >
              <item.icon className={`h-5 w-5 mb-1 ${activeTab === item.value ? (item.color === "brand-primary" || item.color === "brand-accent" ? 'text-white' : (item.color === "gray" ? 'text-brand-secondary' : `text-${item.color}-foreground`)) : (item.color === "brand-primary" || item.color === "brand-accent" ? `text-${item.color}` : (item.color === "gray" ? 'text-neutral-500' : `text-${item.color}-700`)) }`} />
              <span className="text-xs">{item.label}</span>
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>
      <Footer />
      <Toaster />
    </div>
  );
};

export default App;