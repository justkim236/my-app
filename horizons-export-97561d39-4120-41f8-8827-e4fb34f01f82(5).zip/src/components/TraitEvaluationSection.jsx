import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { Brain, TrendingUp, CheckSquare, XSquare, HelpCircle, RotateCcw } from 'lucide-react';
import { Label } from '@/components/ui/label';

const initialTraitQuestions = [
  { id: 'honesty', text: 'Are you honest with your efforts and progress?', type: 'yes_no_maybe' },
  { id: 'learning_speed_exercises', text: 'How quickly do you learn new exercises?', type: 'scale', scaleLabels: ['Slowly', 'Average', 'Quickly'] },
  { id: 'learning_speed_concepts', text: 'How quickly do you grasp new fitness/health concepts?', type: 'scale', scaleLabels: ['Slowly', 'Average', 'Quickly'] },
  { id: 'discipline', text: 'How disciplined are you with your workout routine?', type: 'scale', scaleLabels: ['Needs Work', 'Consistent', 'Very Disciplined'] },
  { id: 'resilience_setbacks', text: 'How do you respond to setbacks or plateaus?', type: 'text_short', placeholder: 'e.g., Get discouraged, Analyze and adjust, Seek help' },
  { id: 'feedback_receptiveness', text: 'Are you open to constructive feedback on your form or approach?', type: 'yes_no_maybe' },
  { id: 'goal_setting', text: 'Do you set clear, achievable fitness goals?', type: 'yes_no_maybe' },
  { id: 'self_motivation', text: 'How strong is your self-motivation to exercise regularly?', type: 'scale', scaleLabels: ['Low', 'Moderate', 'High'] },
  { id: 'patience_results', text: 'Are you patient with seeing results from your efforts?', type: 'yes_no_maybe' },
  { id: 'knowledge_seeking', text: 'Do you actively seek knowledge to improve your fitness and health?', type: 'yes_no_maybe' },
];

const TraitEvaluationSection = ({ onSubmit }) => {
  const { toast } = useToast();
  const [traitAnswers, setTraitAnswers] = useState({});
  const [nextImprovement, setNextImprovement] = useState('');

  const resetForm = () => {
    setTraitAnswers({});
    setNextImprovement('');
  };

  const handleInputChange = (id, value) => {
    setTraitAnswers(prev => ({ ...prev, [id]: value }));
  };

  const handleTraitEvaluationSubmit = (e) => {
    e.preventDefault();
    
    const answeredQuestionsCount = Object.keys(traitAnswers).filter(key => traitAnswers[key] !== '' && traitAnswers[key] !== undefined && traitAnswers[key] !== null).length;

    if (answeredQuestionsCount === 0 && !nextImprovement.trim()) {
      toast({ title: "No Input", description: "Please answer at least one question or provide an area for improvement.", variant: "destructive" });
      return;
    }
    
    onSubmit(
      "Self-Evaluation Submitted",
      "Your self-evaluation has been saved locally. You can update it anytime by submitting a new one.",
      "traitEvaluationEntry", 
      { traits: traitAnswers, notes: nextImprovement, timestamp: new Date().toISOString() }, // Align with DataItemCard structure
      resetForm
    );
  };

  const renderQuestionInput = (question) => {
    const value = traitAnswers[question.id] || '';
    switch (question.type) {
      case 'yes_no_maybe':
        return (
          <div className="flex space-x-2 mt-1">
            {['Yes', 'No', 'Sometimes/Maybe'].map(option => (
              <Button
                key={option}
                type="button"
                variant={value === option ? 'default' : 'outline'}
                size="sm"
                onClick={() => handleInputChange(question.id, option)}
                className={`flex-1 ${value === option ? 'bg-yellow-500 hover:bg-yellow-600 text-black' : 'bg-tan-dark hover:bg-tan-darker border-tan-darker text-neutral-700'}`}
              >
                {option === 'Yes' && <CheckSquare className="mr-1 h-4 w-4" />}
                {option === 'No' && <XSquare className="mr-1 h-4 w-4" />}
                {option === 'Sometimes/Maybe' && <HelpCircle className="mr-1 h-4 w-4" />}
                {option}
              </Button>
            ))}
          </div>
        );
      case 'scale':
        return (
          <div className="flex space-x-2 mt-1">
            {(question.scaleLabels || ['1', '2', '3', '4', '5']).map((label, index) => (
              <Button
                key={label}
                type="button"
                variant={value === (index + 1).toString() ? 'default' : 'outline'} // Ensure value is compared as string
                size="sm"
                onClick={() => handleInputChange(question.id, (index + 1).toString())}
                className={`flex-1 ${value === (index + 1).toString() ? 'bg-yellow-500 hover:bg-yellow-600 text-black' : 'bg-tan-dark hover:bg-tan-darker border-tan-darker text-neutral-700'}`}
              >
                {label}
              </Button>
            ))}
          </div>
        );
      case 'text_short':
        return (
          <input
            type="text"
            value={value}
            onChange={(e) => handleInputChange(question.id, e.target.value)}
            placeholder={question.placeholder || "Your answer..."}
            className="mt-1 border border-tan-dark bg-white text-neutral-800 rounded-md p-2 w-full focus:ring-yellow-500 focus:border-yellow-500"
          />
        );
      default:
        return null;
    }
  };

  return (
    <motion.section 
      className="bg-tan-light/70 backdrop-blur-md rounded-xl p-6 shadow-xl border border-tan-dark md:col-span-2 lg:col-span-3"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 0.2, duration: 0.5 }}
    >
      <div className="flex items-center justify-between text-yellow-600 mb-4">
        <div className="flex items-center">
          <Brain size={28} className="mr-3"/>
          <h2 className="text-2xl font-bold text-brand-secondary">Self-Evaluation: Mentality & Skills</h2>
        </div>
        <Button variant="ghost" size="sm" onClick={resetForm} className="text-yellow-600 hover:bg-yellow-100">
            <RotateCcw size={16} className="mr-1" /> Reset Form
        </Button>
      </div>
      <p className="mb-6 text-neutral-600 text-sm">Reflect on your fitness journey. Answer any questions you find relevant. All inputs are optional. Your latest submission will overwrite previous ones.</p>
      <form onSubmit={handleTraitEvaluationSubmit} className="space-y-6">
        <div className="space-y-4 max-h-[50vh] overflow-y-auto pr-2 custom-scrollbar">
          {initialTraitQuestions.map(q => (
            <div key={q.id} className="p-3 bg-tan/50 rounded-md border border-tan-dark">
              <Label className="block text-sm font-medium text-neutral-700">{q.text}</Label>
              {renderQuestionInput(q)}
            </div>
          ))}
        </div>
        
        <div>
          <Label htmlFor="next-improvement" className="flex items-center mb-1 text-sm font-medium text-neutral-700">
            <TrendingUp size={18} className="mr-2 text-yellow-600"/>
            Key Focus for Next Improvement (Optional Notes):
          </Label>
          <textarea 
            id="next-improvement"
            value={nextImprovement}
            onChange={(e) => setNextImprovement(e.target.value)}
            className="border border-tan-dark bg-white text-neutral-800 rounded-md p-2 w-full h-24 focus:ring-yellow-500 focus:border-yellow-500"
            placeholder="e.g., Improve squat depth, Learn about nutrition timing, Be more consistent with stretching..."
          />
        </div>
        
        <Button type="submit" variant="secondary" className="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-semibold">Submit Self-Evaluation</Button>
      </form>
    </motion.section>
  );
};

export default TraitEvaluationSection;