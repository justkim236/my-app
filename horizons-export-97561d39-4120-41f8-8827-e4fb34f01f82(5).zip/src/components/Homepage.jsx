import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRightCircle, Target, Brain, ShieldCheck, Activity, Puzzle, Eye } from 'lucide-react';

const StepCard = ({ icon, title, description, stepNumber, delay }) => {
  const IconComponent = icon;
  return (
    <motion.div
      className="bg-tan-light/80 backdrop-blur-md p-6 rounded-xl shadow-lg border border-tan-dark hover:shadow-2xl transition-shadow duration-300 flex flex-col items-center text-center h-full"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: delay, duration: 0.5 }}
    >
      <div className="relative mb-4">
        <div className="p-4 bg-brand-primary rounded-full inline-block">
          <IconComponent size={32} className="text-white" />
        </div>
        <span className="absolute -top-2 -right-2 bg-brand-accent text-white text-xs font-bold rounded-full h-6 w-6 flex items-center justify-center">{stepNumber}</span>
      </div>
      <h3 className="text-2xl font-semibold text-brand-secondary mb-2 font-display">{title}</h3>
      <p className="text-neutral-600 text-sm leading-relaxed flex-grow">{description}</p>
    </motion.div>
  );
};

const Homepage = ({ onEnterApp }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-tan-light via-tan to-tan-dark text-brand-secondary flex flex-col items-center justify-center p-4 pt-12 pb-10 overflow-x-hidden">
      <motion.header 
        className="text-center mb-12"
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, type: "spring" }}
      >
        <img  alt="Own Your Pace App Logo - Stylized 'Own Your Pace' text over a gridded background with a book and mouse graphic." className="w-32 h-32 mx-auto mb-4 rounded-full shadow-lg bg-tan-light p-2 border-2 border-brand-primary object-contain" src="https://storage.googleapis.com/hostinger-horizons-assets-prod/97561d39-4120-41f8-8827-e4fb34f01f82/17c2f00f61427e1988f5901bc3131d9e.png" />
        <h1 className="text-5xl md:text-6xl font-extrabold mb-3 bg-clip-text text-transparent bg-gradient-to-r from-orange-500 via-amber-500 to-yellow-600 font-display">
          Own Your Pace
        </h1>
        <p className="text-xl md:text-2xl text-neutral-700 mb-6 max-w-3xl mx-auto">
          Unlock your potential through three simple steps: master exercises, apply knowledge, and understand yourself deeply. Your journey, your rules.
        </p>
      </motion.header>

      <motion.section 
        className="mb-16 max-w-6xl w-full px-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <h2 className="text-3xl md:text-4xl font-bold text-brand-secondary mb-10 text-center font-display">Three Easy Steps to Health & Mindset Mastery</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <StepCard 
            icon={Activity} 
            stepNumber={1}
            title="Watch, Learn & Adapt Exercises" 
            description="Explore exercise videos and learn new movements. Crucially, adapt every exercise to your own unique needs and current capabilities. This is about your body, your way."
            delay={0.3}
          />
          <StepCard 
            icon={Puzzle} 
            stepNumber={2}
            title="Solve Problems, Enhance Learning" 
            description="Use math formulas and problem-solving techniques not just for academics, but to understand the principles behind your exercises and daily challenges. Connect theory to practice."
            delay={0.4}
          />
          <StepCard 
            icon={Eye} 
            stepNumber={3}
            title="Evaluate & Understand Yourself" 
            description="Reflect on your journey, your traits, and your progress. This is where true growth happens. Develop valuable skillsets by deeply understanding your own mind and body."
            delay={0.5}
          />
        </div>
      </motion.section>

      <motion.section 
        className="text-center mb-12 max-w-4xl w-full px-4"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.6, duration: 0.5 }}
      >
        <h2 className="text-3xl md:text-4xl font-bold text-brand-secondary mb-8 font-display">The Core Philosophy: Your Pace, Your Understanding</h2>
        <div className="space-y-6">
          <div className="bg-tan-light/50 p-6 rounded-lg border border-tan-dark shadow-md flex items-start md:items-center">
            <Target size={36} className="text-brand-primary mr-4 mt-1 md:mt-0 shrink-0" />
            <div>
              <h4 className="text-xl font-semibold text-neutral-700 mb-1 font-display">Only You Know Your Pace</h4>
              <p className="text-sm text-neutral-600 leading-relaxed">This journey is yours alone. There are no external deadlines, only the rhythm you set. Progress is personal. Never compare your chapter 1 to someone else's chapter 20.</p>
            </div>
          </div>
          <div className="bg-tan-light/50 p-6 rounded-lg border border-tan-dark shadow-md flex items-start md:items-center">
            <ShieldCheck size={36} className="text-brand-primary mr-4 mt-1 md:mt-0 shrink-0" />
            <div>
              <h4 className="text-xl font-semibold text-neutral-700 mb-1 font-display">Only You Know Your Body</h4>
              <p className="text-sm text-neutral-600 leading-relaxed">Listen to your body's signals. Understand how it functions, its limits, and its strengths. Adapt all activities to respect its unique wisdom and needs.</p>
            </div>
          </div>
           <div className="bg-tan-light/50 p-6 rounded-lg border border-tan-dark shadow-md flex items-start md:items-center">
            <Brain size={36} className="text-brand-primary mr-4 mt-1 md:mt-0 shrink-0" />
            <div>
              <h4 className="text-xl font-semibold text-neutral-700 mb-1 font-display">Develop In-Demand Skillsets</h4>
              <p className="text-sm text-neutral-600 leading-relaxed">Through these three steps, you're not just improving health; you're building discipline, critical thinking, self-awareness, and adaptability—skills for life.</p>
            </div>
          </div>
        </div>
      </motion.section>
      
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8, duration: 0.5 }}
        className="mb-8"
      >
        <Button 
          onClick={onEnterApp} 
          size="lg" 
          className="bg-brand-accent hover:bg-brand-accent/90 text-accent-foreground font-semibold py-4 px-10 text-lg rounded-full shadow-xl transition-transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-brand-accent/50"
        >
          Begin Your Journey <ArrowRightCircle size={22} className="ml-3" />
        </Button>
      </motion.div>

      <footer className="mt-12 text-center text-neutral-500 text-sm">
        <p>&copy; {new Date().getFullYear()} Own Your Pace. Your journey, your rules. Embrace self-discovery.</p>
      </footer>
    </div>
  );
};

export default Homepage;