import React, { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { BookOpen, UploadCloud, PlusCircle, Sigma, Link, Plus, Trash2 } from 'lucide-react';
import FileInput from '@/components/FileInput';

const MathFormulaSection = ({ onSubmit }) => {
  const { toast } = useToast();
  const [description, setDescription] = useState('');
  const [relatedExercise, setRelatedExercise] = useState('');
  const [formulaFile, setFormulaFile] = useState(null);
  const [filePreview, setFilePreview] = useState(null);
  const [latexInput, setLatexInput] = useState('');
  const [externalLinks, setExternalLinks] = useState(['']);

  const resetForm = useCallback(() => {
    setDescription('');
    setRelatedExercise('');
    setFormulaFile(null);
    setFilePreview(null);
    setLatexInput('');
    setExternalLinks(['']);
  }, []);

  const handleFileChange = (file) => {
    if (file) {
      setFormulaFile(file);
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onloadend = () => {
          setFilePreview(reader.result);
        };
        reader.readAsDataURL(file);
      } else {
        setFilePreview(null);
      }
    } else {
      setFormulaFile(null);
      setFilePreview(null);
    }
  };

  const addLinkField = () => {
    setExternalLinks([...externalLinks, '']);
  };

  const removeLinkField = (index) => {
    setExternalLinks(externalLinks.filter((_, i) => i !== index));
  };

  const updateLink = (index, value) => {
    const newLinks = [...externalLinks];
    newLinks[index] = value;
    setExternalLinks(newLinks);
  };

  const handleFormulaSubmit = (e) => {
    e.preventDefault();
    if (!description.trim()) {
      toast({ title: "Missing Description", description: "Please provide a description for the math formula.", variant: "destructive" });
      return;
    }

    if (!relatedExercise.trim()) {
      toast({ title: "Missing Exercise", description: "Please specify which exercise this formula is for.", variant: "destructive" });
      return;
    }

    const validLinks = externalLinks.filter(link => link.trim() !== '');
    if (!formulaFile && !latexInput.trim() && validLinks.length === 0) {
      toast({ title: "Missing Content", description: "Please upload an image/ZIP, provide LaTeX, or add at least one external link.", variant: "destructive" });
      return;
    }

    const invalidLinks = validLinks.filter(link => !link.startsWith('http'));
    if (invalidLinks.length > 0) {
      toast({ title: "Invalid Links", description: "All external links must start with http:// or https://", variant: "destructive" });
      return;
    }

    if (formulaFile) {
      const MAX_SIZE_2TB = 2 * 1024 * 1024 * 1024 * 1024;
      if (formulaFile.size > MAX_SIZE_2TB) {
        toast({
          title: "File Too Large",
          description: `The file exceeds the simulated 2TB limit. (Actual browser limits are much smaller)`,
          variant: "destructive",
        });
        return;
      }
    }
    
    onSubmit(
      "Math Formula Added!",
      "Your math formula and its details have been saved locally.",
      "mathFormulaEntries",
      { 
        id: Date.now().toString(),
        description,
        relatedExercise,
        imageName: formulaFile ? formulaFile.name : null,
        size: formulaFile ? formulaFile.size : null,
        previewUrl: filePreview,
        latexString: latexInput.trim() || null,
        externalLinks: validLinks.length > 0 ? validLinks : null,
        timestamp: new Date().toISOString()
      },
      resetForm
    );
  };

  return (
    <motion.section 
      className="bg-tan-light/70 backdrop-blur-md rounded-xl p-6 shadow-xl border border-tan-dark"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1, duration: 0.5 }}
    >
      <div className="flex items-center text-amber-700 mb-4">
        <BookOpen size={28} className="mr-3"/>
        <h2 className="text-2xl font-bold text-brand-secondary">Add Math Formula</h2>
      </div>
      <form onSubmit={handleFormulaSubmit} className="space-y-6">
        <div>
          <label htmlFor="formula-description" className="block mb-1 text-sm font-medium text-neutral-700">Formula Description:</label>
          <textarea 
            id="formula-description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="border border-tan-dark bg-white text-neutral-800 rounded-md p-2 w-full h-24 focus:ring-brand-primary focus:border-brand-primary"
            placeholder="e.g., Formula for calculating VO2 Max..."
            required
          />
        </div>
        <div>
          <label htmlFor="related-exercise" className="block mb-1 text-sm font-medium text-neutral-700">Related Exercise:</label>
          <input 
            type="text"
            id="related-exercise"
            value={relatedExercise}
            onChange={(e) => setRelatedExercise(e.target.value)}
            className="border border-tan-dark bg-white text-neutral-800 rounded-md p-2 w-full focus:ring-brand-primary focus:border-brand-primary"
            placeholder="e.g., Cooper Test"
            required
          />
        </div>
        <div>
          <label className="block mb-1 text-sm font-medium text-neutral-700">Upload Image or ZIP (Optional):</label>
          <FileInput 
            onFileChange={handleFileChange} 
            acceptedFileTypes={{ 'image/*': ['.png', '.jpg', '.jpeg', '.gif'], 'application/zip': ['.zip'] }}
            buttonText="Choose Formula File"
            buttonIcon={<UploadCloud size={18} className="mr-2"/>}
            currentFile={formulaFile}
          />
          {formulaFile && <p className="text-xs text-neutral-600 mt-1">Selected: {formulaFile.name} ({(formulaFile.size / (1024*1024)).toFixed(2)} MB)</p>}
          {filePreview && formulaFile?.type.startsWith('image/') && (
            <img-replace src={filePreview} alt={`Preview of ${formulaFile.name || 'uploaded formula'}`} className="mt-2 rounded-md max-h-40 border border-tan-dark w-auto" />
          )}
        </div>
        <div>
          <label htmlFor="latex-input" className="flex items-center mb-1 text-sm font-medium text-neutral-700">
            <Sigma size={16} className="mr-2 text-amber-700" /> LaTeX Formula (Optional):
          </label>
          <textarea
            id="latex-input"
            value={latexInput}
            onChange={(e) => setLatexInput(e.target.value)}
            className="border border-tan-dark bg-white text-neutral-800 rounded-md p-2 w-full h-20 font-mono text-sm focus:ring-brand-primary focus:border-brand-primary"
            placeholder="e.g., x = \frac{-b \pm \sqrt{b^2-4ac}}{2a}"
          />
          <p className="text-xs text-neutral-500 mt-1">Enter LaTeX code. It will be rendered using MathJax.</p>
        </div>
        <div>
          <label className="flex items-center justify-between mb-1 text-sm font-medium text-neutral-700">
            <span className="flex items-center">
              <Link size={16} className="mr-2 text-amber-700" /> External Links (Optional):
            </span>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={addLinkField}
              className="h-7 px-2 text-xs border-amber-500 text-amber-700 hover:bg-amber-50"
            >
              <Plus size={14} className="mr-1"/> Add Another Link
            </Button>
          </label>
          <div className="space-y-2">
            {externalLinks.map((link, index) => (
              <div key={index} className="flex gap-2">
                <input
                  type="url"
                  value={link}
                  onChange={(e) => updateLink(index, e.target.value)}
                  className="flex-grow border border-tan-dark bg-white text-neutral-800 rounded-md p-2 focus:ring-brand-primary focus:border-brand-primary"
                  placeholder="e.g., https://example.com/document.pdf"
                />
                {externalLinks.length > 1 && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => removeLinkField(index)}
                    className="h-10 w-10 text-red-500 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 size={16}/>
                  </Button>
                )}
              </div>
            ))}
          </div>
          <p className="text-xs text-neutral-500 mt-1">Add links to external files or resources.</p>
        </div>
        <Button type="submit" variant="secondary" className="w-full bg-brand-primary hover:bg-brand-primary/90 text-primary-foreground font-semibold">
          <PlusCircle size={20} className="mr-2"/> Add Formula
        </Button>
      </form>
    </motion.section>
  );
};

export default MathFormulaSection;