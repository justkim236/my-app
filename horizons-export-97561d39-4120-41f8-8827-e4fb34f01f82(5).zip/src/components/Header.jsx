import React from 'react';
import { motion } from 'framer-motion';

const Header = () => {
  return (
    <header className="bg-tan-light/50 backdrop-blur-md text-brand-secondary text-center py-6 px-4 shadow-lg border-b border-tan-dark">
      <motion.h1 
        className="text-4xl font-extrabold mb-1 bg-clip-text text-transparent bg-gradient-to-r from-orange-500 via-amber-500 to-yellow-600 font-display"
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, type: "spring", stiffness: 100 }}
      >
        Own Your Pace
      </motion.h1>
      <motion.p 
        className="text-md text-neutral-700"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.5 }}
      >
        Elevate Your Mind, Body, and Spirit
      </motion.p>
    </header>
  );
};

export default Header;