import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { MessageSquare, Edit3, ShieldAlert, Send, Info } from 'lucide-react';

const FeedbackSection = ({ onSubmit }) => {
  const { toast } = useToast();
  const [feedbackType, setFeedbackType] = useState('reflection');
  const [feedbackMessage, setFeedbackMessage] = useState('');
  const [relatedItem, setRelatedItem] = useState('');
  const [privacyAgreed, setPrivacyAgreed] = useState(false);
  const [rating, setRating] = useState(0);
  const [workoutDate, setWorkoutDate] = useState(new Date().toISOString().split('T')[0]);

  const resetForm = () => {
    setFeedbackMessage('');
    setRelatedItem('');
    setPrivacyAgreed(false);
    setRating(0);
    setWorkoutDate(new Date().toISOString().split('T')[0]);
  };

  const handleFeedbackSubmit = (e) => {
    e.preventDefault();
    if (!feedbackMessage.trim()) {
      toast({ title: "Missing Message", description: "Please provide your reflection or feedback.", variant: "destructive" });
      return;
    }

    if (!privacyAgreed) {
      toast({ 
        title: "Privacy Agreement Required", 
        description: "You must agree to the privacy terms before submitting.", 
        variant: "destructive",
        icon: <ShieldAlert className="h-6 w-6 text-red-500" />
      });
      return;
    }

    if (feedbackType === 'reflection' && rating === 0) {
      toast({ title: "Rating Required", description: "Please provide a rating for your workout reflection.", variant: "destructive" });
      return;
    }
    
    let title = "Workout Reflection Saved!";
    let description = "Your thoughts have been recorded privately.";
    if (feedbackType !== 'reflection') {
      title = "Feedback Submitted!";
      description = "Thank you for your feedback/question. We'll review it. It has been submitted privately.";
    }

    const entryData = { 
      id: Date.now().toString(), 
      reflectionType: feedbackType,
      text: feedbackMessage,
      relatedItem: feedbackType.includes('question') ? relatedItem : undefined, 
      timestamp: new Date().toISOString(),
      privacyAgreed: true,
      ...(feedbackType === 'reflection' && { rating, workoutDate })
    };

    onSubmit(
      title,
      description,
      "feedbackEntries",
      entryData,
      resetForm
    );
  };

  return (
    <motion.section 
      className="bg-tan-light/70 backdrop-blur-md rounded-xl p-6 shadow-xl border border-tan-dark md:col-span-2 lg:col-span-3"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3, duration: 0.5 }}
    >
      <div className="flex items-center text-lime-600 mb-4">
        {feedbackType === 'reflection' ? <Edit3 size={28} className="mr-3"/> : <MessageSquare size={28} className="mr-3"/>}
        <h2 className="text-2xl font-bold text-brand-secondary">Workout Reflections & Feedback</h2>
      </div>
      <p className="mb-4 text-neutral-600 text-sm">
        {feedbackType === 'reflection' 
          ? "Describe your experience after exercising, your achievements, or areas for improvement."
          : "Share your thoughts to help us improve, or ask any questions about exercises or formulas."}
      </p>
      <form onSubmit={handleFeedbackSubmit} className="space-y-6">
        <div>
          <Label htmlFor="feedback-type" className="block mb-1 text-sm font-medium text-neutral-700">Entry Type:</Label>
          <select
            id="feedback-type"
            value={feedbackType}
            onChange={(e) => setFeedbackType(e.target.value)}
            className="border border-tan-dark bg-white text-neutral-800 rounded-md p-2 w-full focus:ring-lime-500 focus:border-lime-500"
          >
            <option value="reflection">Workout Reflection</option>
            <option value="general_feedback">General App Feedback</option>
            <option value="exercise_question">Question about an Exercise</option>
            <option value="formula_question">Question about a Math Formula</option>
            <option value="bug_report">Bug Report</option>
            <option value="feature_request">Feature Request</option>
          </select>
        </div>

        {feedbackType === 'reflection' && (
          <>
            <div>
              <Label htmlFor="workout-date" className="block mb-1 text-sm font-medium text-neutral-700">Workout Date:</Label>
              <input
                type="date"
                id="workout-date"
                value={workoutDate}
                onChange={(e) => setWorkoutDate(e.target.value)}
                className="border border-tan-dark bg-white text-neutral-800 rounded-md p-2 w-full focus:ring-lime-500 focus:border-lime-500"
              />
            </div>
            <div>
              <Label className="block mb-1 text-sm font-medium text-neutral-700">Workout Rating (1-5 Stars):</Label>
              <div className="flex space-x-1">
                {[1, 2, 3, 4, 5].map(star => (
                  <Button
                    key={star}
                    type="button"
                    variant={rating === star ? "default" : "outline"}
                    onClick={() => setRating(star)}
                    className={`w-full ${rating === star ? 'bg-lime-500 hover:bg-lime-600 text-white' : 'bg-tan-dark hover:bg-tan-darker border-tan-darker text-neutral-700'}`}
                  >
                    {star} ★
                  </Button>
                ))}
              </div>
            </div>
          </>
        )}

        {(feedbackType === 'exercise_question' || feedbackType === 'formula_question') && (
          <div>
            <Label htmlFor="related-item" className="block mb-1 text-sm font-medium text-neutral-700">
              {feedbackType === 'exercise_question' ? 'Related Exercise Name:' : 'Related Formula Topic:'}
            </Label>
            <input
              type="text"
              id="related-item"
              value={relatedItem}
              onChange={(e) => setRelatedItem(e.target.value)}
              className="border border-tan-dark bg-white text-neutral-800 rounded-md p-2 w-full focus:ring-lime-500 focus:border-lime-500"
              placeholder={feedbackType === 'exercise_question' ? 'E.g., Interval Sprints' : 'E.g., Kinematic Equations'}
            />
          </div>
        )}

        <div>
          <Label htmlFor="feedback-message" className="block mb-1 text-sm font-medium text-neutral-700">
            {feedbackType === 'reflection' ? 'Your Reflection:' : 'Your Message:'}
          </Label>
          <textarea 
            id="feedback-message"
            value={feedbackMessage}
            onChange={(e) => setFeedbackMessage(e.target.value)}
            className="border border-tan-dark bg-white text-neutral-800 rounded-md p-2 w-full h-32 focus:ring-lime-500 focus:border-lime-500"
            placeholder={feedbackType === 'reflection' ? 'Type your reflection here...' : 'Type your feedback or question here...'}
            required
          />
        </div>

        <div className="flex items-start space-x-3 p-3 bg-tan-dark/30 rounded-md border border-tan-dark">
          <Checkbox 
            id="privacy-agreement" 
            checked={privacyAgreed}
            onCheckedChange={setPrivacyAgreed}
            className="border-tan-dark data-[state=checked]:bg-lime-600 data-[state=checked]:border-lime-700 mt-1"
            aria-label="Agree to privacy terms"
          />
          <div>
            <Label htmlFor="privacy-agreement" className="text-sm font-medium text-neutral-700 cursor-pointer">
              Privacy Agreement
            </Label>
            <p className="text-xs text-neutral-600">
              I understand that my feedback is submitted privately and will not be shared publicly or with other users. It will be used solely for improving this application or addressing my questions.
            </p>
          </div>
        </div>

        <Button type="submit" variant="secondary" className="w-full bg-lime-600 hover:bg-lime-700 text-white font-semibold">
          <Send size={18} className="mr-2" />
          {feedbackType === 'reflection' ? 'Save Reflection' : 'Submit Feedback'}
        </Button>

        <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-md text-center">
          <div className="flex items-center justify-center text-blue-600 mb-1">
            <Info size={18} className="mr-2" />
            <span className="font-semibold text-sm">Data Handling & Privacy</span>
          </div>
          <p className="text-xs text-blue-500">
            Your submissions are stored securely. For any concerns or data removal requests, please contact us at <a href="mailto:privacy@ownyourpace.app" className="underline hover:text-blue-700">privacy@ownyourpace.app</a> (example email). We are committed to protecting your privacy.
          </p>
        </div>
      </form>
    </motion.section>
  );
};

export default FeedbackSection;