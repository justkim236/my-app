import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { formatTimestamp, formatFileSize, getFileIcon } from './dataDisplayUtils';
import { motion } from 'framer-motion';
import { Trash2, Edit3, Download, PlayCircle, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import MathJaxFormula from '@/components/MathJaxFormula';

const DataItemCard = ({ item, type, onEdit, onDelete, onDownload }) => {
  const FileDisplayIcon = getFileIcon(item.originalFileName || item.imageName || item.fileName || (item.videoUrl ? 'video' : null) || (type === 'trait_evaluation' ? 'brain' : (type === 'reflections' ? 'edit-3' : 'file-text')));

  const isDirectVideoLink = (url) => {
    return url && (url.endsWith('.mp4') || url.endsWith('.webm') || url.endsWith('.ogg'));
  };

  const renderContent = () => {
    switch (type) {
      case 'videos':
        return (
          <>
            {item.videoUrl ? (
              <div className="space-y-2">
                <p className="text-sm text-neutral-600">
                  <strong>URL:</strong> 
                  <a href={item.videoUrl} target="_blank" rel="noopener noreferrer" className="ml-1 text-blue-600 hover:text-blue-800 hover:underline break-all">
                    {item.videoUrl.length > 60 ? `${item.videoUrl.substring(0, 60)}...` : item.videoUrl} 
                    <ExternalLink size={12} className="inline-block ml-1" />
                  </a>
                </p>
                {isDirectVideoLink(item.videoUrl) && (
                  <video controls src={item.videoUrl} className="mt-2 rounded-md max-h-60 w-full border border-tan-dark bg-black">
                    Your browser does not support the video tag or the video format is not supported.
                  </video>
                )}
              </div>
            ) : (
              <>
                <p className="text-sm text-neutral-600"><strong>File:</strong> {item.originalFileName}</p>
                <p className="text-sm text-neutral-600"><strong>Size:</strong> {formatFileSize(item.size)}</p>
                {item.previewUrl && item.originalFileName && item.originalFileName.match(/\.(mp4|webm|ogg)$/i) && (
                  <video controls src={item.previewUrl} className="mt-2 rounded-md max-h-48 w-full border border-tan-dark">
                    Your browser does not support the video tag.
                  </video>
                )}
              </>
            )}
          </>
        );
      case 'formulas':
        return (
          <>
            {item.relatedExercise && (
              <div className="flex items-center justify-between mb-3">
                <p className="text-sm text-neutral-600">
                  <strong>Exercise:</strong> {item.relatedExercise}
                </p>
              </div>
            )}
            {item.imageName && (
              <>
                <p className="text-sm text-neutral-600"><strong>File:</strong> {item.imageName}</p>
                <p className="text-sm text-neutral-600"><strong>Size:</strong> {formatFileSize(item.size)}</p>
              </>
            )}
            {item.previewUrl && item.imageName && item.imageName.match(/\.(jpeg|jpg|gif|png)$/i) && (
               <img-replace src={item.previewUrl} alt={item.description || 'Formula preview'} className="mt-2 rounded-md max-h-40 w-auto border border-tan-dark" />
            )}
            {item.latexString && (
              <div className="mt-3">
                <p className="text-sm font-semibold text-amber-800 mb-1">Rendered LaTeX Formula:</p>
                <MathJaxFormula latex={item.latexString} />
              </div>
            )}
            {item.externalLinks && item.externalLinks.length > 0 && (
              <div className="mt-3">
                <p className="text-sm font-semibold text-amber-800 mb-1">External Resources:</p>
                <div className="space-y-2">
                  {item.externalLinks.map((link, index) => (
                    <a 
                      key={index}
                      href={link} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="block text-sm text-blue-600 hover:text-blue-800 hover:underline break-all"
                    >
                      <ExternalLink size={14} className="inline-block mr-1.5" /> 
                      {link.length > 50 ? `${link.substring(0, 50)}...` : link}
                    </a>
                  ))}
                </div>
              </div>
            )}
            {!item.imageName && !item.latexString && (!item.externalLinks || item.externalLinks.length === 0) && (
              <p className="text-sm text-neutral-500 italic">No file, LaTeX, or external links provided for this formula.</p>
            )}
          </>
        );
      case 'trait_evaluation': 
        return (
          <div className="space-y-2 text-sm text-neutral-700">
            {item.traits && Object.keys(item.traits).length > 0 ? (
              Object.entries(item.traits).map(([traitId, value]) => {
                const questionText = traitId.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()); 
                return (
                  <div key={traitId} className="py-1">
                    <strong className="block text-neutral-800">{questionText}:</strong> 
                    <span className="text-amber-700">{typeof value === 'string' ? value : `${value}/5`}</span>
                  </div>
                );
              })
            ) : (
              <p className="italic text-neutral-500">No specific traits answered.</p>
            )}
            {item.notes && (
              <div className="mt-2 pt-2 border-t border-tan-dark">
                <strong className="block text-neutral-800">Focus for Next Improvement:</strong> 
                <p className="whitespace-pre-wrap">{item.notes}</p>
              </div>
            )}
             {!item.traits && !item.notes &&  Object.keys(item.traits || {}).length === 0 && <p className="italic text-neutral-500">No evaluation data recorded.</p>}
          </div>
        );
      case 'reflections': 
        return (
          <>
            {item.reflectionType && <p className="text-sm text-neutral-600"><strong>Type:</strong> <span className="font-medium text-lime-700">{item.reflectionType.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</span></p>}
            {item.workoutDate && <p className="text-sm text-neutral-600"><strong>Workout Date:</strong> {formatTimestamp(item.workoutDate, false)}</p>}
            {item.rating && <p className="text-sm text-neutral-600"><strong>Rating:</strong> <span className="text-amber-500 font-bold">{item.rating}/5 ★</span></p>}
            {item.relatedItem && <p className="text-sm text-neutral-600"><strong>Related To:</strong> {item.relatedItem}</p>}
            <p className="text-sm text-neutral-700 whitespace-pre-wrap mt-2 pt-2 border-t border-tan-dark">{item.text}</p>
          </>
        );
      default:
        return <p className="text-sm text-neutral-600">No specific display for this data type.</p>;
    }
  };

  const cardTitle = item.videoName || item.description || (item.reflectionType ? item.reflectionType.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) : null) || `Entry`;
  const cardDescription = type === 'trait_evaluation' ? `Evaluation from ${formatTimestamp(item.timestamp)}` : `Added: ${formatTimestamp(item.timestamp)}`;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="w-full shadow-lg hover:shadow-xl transition-shadow duration-300 bg-white/80 backdrop-blur-sm border-tan-dark overflow-hidden flex flex-col h-full">
        <CardHeader className="pb-3 bg-tan-light/30 border-b border-tan-dark">
          <div className="flex items-start justify-between">
            <div className="flex items-center min-w-0"> 
              <FileDisplayIcon size={22} className="mr-3 text-brand-primary flex-shrink-0" />
              <CardTitle className="text-lg font-semibold text-brand-secondary leading-tight truncate">{cardTitle}</CardTitle>
            </div>
            {(onDelete || onEdit || onDownload || (item.externalLinks && type === 'formulas') || (item.videoUrl && type === 'videos')) && (
              <div className="flex space-x-1 flex-shrink-0 ml-2">
                {onEdit && <Button variant="ghost" size="icon" onClick={() => onEdit(item)} className="h-7 w-7 text-blue-600 hover:text-blue-700 hover:bg-blue-100"><Edit3 size={16}/></Button>}
                
                {onDownload && (item.originalFileName || item.imageName) && 
                  <Button variant="ghost" size="icon" onClick={() => onDownload(item)} className="h-7 w-7 text-green-600 hover:text-green-700 hover:bg-green-100"><Download size={16}/></Button>
                }
                {item.externalLinks && item.externalLinks.length > 0 && type === 'formulas' && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => window.open(item.externalLinks[0], '_blank')}
                    className="h-7 w-7 text-purple-600 hover:text-purple-700 hover:bg-purple-100"
                  >
                    <ExternalLink size={16}/>
                  </Button>
                )}
                {item.videoUrl && type === 'videos' && (
                  <a href={item.videoUrl} target="_blank" rel="noopener noreferrer" className="h-7 w-7 inline-flex items-center justify-center rounded-md text-purple-600 hover:text-purple-700 hover:bg-purple-100 transition-colors" title="Open video link">
                    <ExternalLink size={16}/>
                  </a>
                )}
                {onDelete && <Button variant="ghost" size="icon" onClick={() => onDelete(item.id)} className="h-7 w-7 text-red-500 hover:text-red-700 hover:bg-red-100"><Trash2 size={16}/></Button>}
              </div>
            )}
          </div>
          <CardDescription className="text-xs text-neutral-500 pt-1">{cardDescription}</CardDescription>
        </CardHeader>
        <CardContent className="py-4 px-5 flex-grow"> 
          {renderContent()}
        </CardContent>
        {(type === 'videos' && item.videoUrl && isDirectVideoLink(item.videoUrl)) && (
          <CardFooter className="p-0 mt-auto"> 
            <Button 
              variant="ghost" 
              className="w-full justify-center rounded-none rounded-b-lg bg-brand-accent/10 hover:bg-brand-accent/20 text-brand-accent py-3"
              onClick={() => {
                const videoElement = document.querySelector(`video[src="${item.videoUrl}"]`);
                if (videoElement) {
                  if (videoElement.paused) {
                    videoElement.play();
                  } else {
                    videoElement.pause();
                  }
                }
              }}
            >
              <PlayCircle size={18} className="mr-2"/> Play/Pause Video
            </Button>
          </CardFooter>
        )}
      </Card>
    </motion.div>
  );
};

export default DataItemCard;