import React from 'react';
import { Film, BookOpen, MessageSquare, Edit3, UserCheck, FileText, Image as ImageIcon, Archive, Brain } from 'lucide-react'; // Added Brain

export const getIconForItemType = (itemType, activeColorClass = "text-gray-700") => {
  switch (itemType) {
    case 'videos': return <Film className={`mr-2 h-5 w-5 ${activeColorClass === "text-gray-700" ? "text-brand-accent" : activeColorClass}`} />;
    case 'formulas': return <BookOpen className={`mr-2 h-5 w-5 ${activeColorClass === "text-gray-700" ? "text-orange-600" : activeColorClass}`} />;
    case 'reflection': return <Edit3 className={`mr-2 h-5 w-5 ${activeColorClass === "text-gray-700" ? "text-lime-600" : activeColorClass}`} />;
    case 'trait_evaluation': return <UserCheck className={`mr-2 h-5 w-5 ${activeColorClass === "text-gray-700" ? "text-yellow-600" : activeColorClass}`} />;
    default: return <MessageSquare className={`mr-2 h-5 w-5 ${activeColorClass === "text-gray-700" ? "text-green-600" : activeColorClass}`} />;
  }
};

export const getOverallIconForDisplayTab = (type, filterType, filterTypeExclude) => {
   if (type === 'videos') return <Film className="mr-3 h-6 w-6 text-brand-accent" />;
   if (type === 'formulas') return <BookOpen className="mr-3 h-6 w-6 text-orange-600" />;
   if (type === 'trait_evaluation') return <UserCheck className="mr-3 h-6 w-6 text-yellow-600" />; // Was Brain, changed to UserCheck for consistency
   if (type === 'reflections' && filterType === 'reflection') return <Edit3 className="mr-3 h-6 w-6 text-lime-600" />;
   if (type === 'reflections' && filterTypeExclude === 'reflection') return <MessageSquare className="mr-3 h-6 w-6 text-green-600" />;
   return <MessageSquare className="mr-3 h-6 w-6 text-neutral-500" />; // Default
};

export const traitQuestionsMap = {
  honesty: 'Are you honest with your efforts and progress?',
  learning_speed_exercises: 'How quickly do you learn new exercises?',
  learning_speed_concepts: 'How quickly do you grasp new fitness/health concepts?',
  discipline: 'How disciplined are you with your workout routine?',
  resilience_setbacks: 'How do you respond to setbacks or plateaus?',
  feedback_receptiveness: 'Are you open to constructive feedback on your form or approach?',
  goal_setting: 'Do you set clear, achievable fitness goals?',
  self_motivation: 'How strong is your self-motivation to exercise regularly?',
  patience_results: 'Are you patient with seeing results from your efforts?',
  knowledge_seeking: 'Do you actively seek knowledge to improve your fitness and health?',
};

export const scaleLabelsMap = {
  learning_speed_exercises: ['Slowly', 'Average', 'Quickly'],
  learning_speed_concepts: ['Slowly', 'Average', 'Quickly'],
  discipline: ['Needs Work', 'Consistent', 'Very Disciplined'],
  self_motivation: ['Low', 'Moderate', 'High'],
};

export const formatTimestamp = (timestamp, includeTime = true) => {
  if (!timestamp) return 'N/A';
  const date = new Date(timestamp);
  if (isNaN(date.getTime())) return 'Invalid Date';

  const optionsDate = { year: 'numeric', month: 'short', day: 'numeric' };
  const optionsTime = { hour: '2-digit', minute: '2-digit' };
  
  let formattedDate = date.toLocaleDateString(undefined, optionsDate);
  if (includeTime) {
    formattedDate += `, ${date.toLocaleTimeString(undefined, optionsTime)}`;
  }
  return formattedDate;
};

export const formatFileSize = (bytes) => {
  if (bytes === null || bytes === undefined || isNaN(Number(bytes))) return 'N/A';
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export const getFileIcon = (fileNameOrType) => {
  if (!fileNameOrType || typeof fileNameOrType !== 'string') return FileText; 
  
  // Handle specific types first for clarity if passed directly
  if (fileNameOrType === 'brain') return Brain;
  if (fileNameOrType === 'edit-3') return Edit3;

  const extension = fileNameOrType.split('.').pop().toLowerCase();
  if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'].includes(extension)) {
    return ImageIcon;
  }
  if (['mp4', 'webm', 'ogg', 'mov', 'avi'].includes(extension)) {
    return Film;
  }
  if (['zip', 'rar', '7z', 'tar', 'gz'].includes(extension)) {
    return Archive;
  }
  if (['pdf', 'doc', 'docx', 'txt', 'md'].includes(extension)) {
    return FileText;
  }
  return FileText; // Default icon
};