import React from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle, Info } from 'lucide-react';

const EmptyStateDisplay = ({ title, type }) => {
  const typeText = type.toLowerCase().replace(/_/g, ' ');
  let entryText = title.toLowerCase().includes("feedback") || title.toLowerCase().includes("reflections") || title.toLowerCase().includes("evaluations") ? "entries" : typeText;
  
  // Specific handling for trait_evaluation
  if (type === 'trait_evaluation') {
    entryText = 'self-evaluation';
  }


  let message = `No ${entryText} found.`;
  if (type === 'trait_evaluation') {
    message = "No self-evaluation submitted yet. Your latest submission will appear here.";
  } else {
    message = `Your ${entryText} will appear here once submitted.`;
  }


  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center justify-center h-auto min-h-[200px] text-neutral-500 bg-tan/30 rounded-lg p-8 border-2 border-dashed border-tan-dark"
    >
      <Info size={48} className="mb-4 text-amber-500" />
      <h3 className="text-xl font-semibold text-brand-secondary mb-2">{title}</h3>
      <p className="text-center text-sm max-w-md">{message}</p>
    </motion.div>
  );
};

export default EmptyStateDisplay;