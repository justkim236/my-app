import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';
import DataItemCard from './data_display/DataItemCard';
import EmptyStateDisplay from './data_display/EmptyStateDisplay';
import { getOverallIconForDisplayTab } from './data_display/dataDisplayUtils';

const DataDisplayTabs = ({ type, storageKey, title, refreshKey, filterType, filterTypeExclude, isSingleEntry = false }) => {
  const [data, setData] = useState([]);
  const { toast } = useToast();

  const fetchData = () => {
    try {
      let storedData = JSON.parse(localStorage.getItem(storageKey));
      if (isSingleEntry) {
        setData(storedData ? [storedData] : []); 
      } else {
        storedData = storedData || [];
        if (Array.isArray(storedData)) {
          if (filterType) {
            storedData = storedData.filter(item => item.reflectionType === filterType); // Changed item.type to item.reflectionType
          }
          if (filterTypeExclude) {
            storedData = storedData.filter(item => item.reflectionType !== filterTypeExclude); // Changed item.type to item.reflectionType
          }
          setData(storedData.reverse()); // Show newest first
        } else {
          setData([]);
        }
      }
    } catch (error) {
      console.error(`Error fetching ${type} from localStorage:`, error);
      setData([]);
      toast({
        title: "Error Loading Data",
        description: `Could not load ${type.toLowerCase()} data. Your browser's local storage might be full or disabled.`,
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    fetchData();
  }, [storageKey, refreshKey, type, filterType, filterTypeExclude, isSingleEntry]);

  const handleDeleteItem = (itemId) => {
    try {
      if (isSingleEntry) {
        localStorage.removeItem(storageKey);
      } else {
        const currentData = JSON.parse(localStorage.getItem(storageKey)) || [];
        const updatedData = currentData.filter(item => item.id !== itemId);
        localStorage.setItem(storageKey, JSON.stringify(updatedData));
      }
      fetchData(); // Re-fetch to update the UI
      toast({
        title: "Item Deleted",
        description: `The selected item has been deleted.`,
        variant: "default",
      });
    } catch (error) {
      console.error(`Error deleting item from ${storageKey}:`, error);
      toast({
        title: "Deletion Error",
        description: `Could not delete the item.`,
        variant: "destructive",
      });
    }
  };
  
  if (data.length === 0) {
    return <EmptyStateDisplay title={title} type={type} />;
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      <h2 className="text-3xl font-bold text-center mb-8 text-brand-secondary flex items-center justify-center">
        {getOverallIconForDisplayTab(type, filterType, filterTypeExclude)} {title}
      </h2>
      <div className={`grid grid-cols-1 ${isSingleEntry ? 'md:grid-cols-1 lg:grid-cols-1 max-w-2xl mx-auto' : 'md:grid-cols-2 lg:grid-cols-3'} gap-6`}>
        <AnimatePresence>
          {data.map((item, index) => (
            <DataItemCard 
              key={item.id || item.timestamp || index} 
              item={item} 
              type={type} 
              onDelete={handleDeleteItem}
            />
          ))}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};

export default DataDisplayTabs;