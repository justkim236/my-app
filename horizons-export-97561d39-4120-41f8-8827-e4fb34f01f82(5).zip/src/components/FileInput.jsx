import React from 'react';
import { UploadCloud } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

const FileInput = ({ 
  onFileChange, 
  acceptedFileTypes = {}, 
  buttonText = "Choose File", 
  buttonIcon,
  fileTypeDescription = "Max 2TB (Simulated)",
  currentFile // This prop is now used to display the name
}) => {
  const acceptString = Object.entries(acceptedFileTypes)
    .map(([mimeType, extensions]) => {
      if (extensions && extensions.length > 0) {
        return extensions.join(',');
      }
      return mimeType;
    })
    .join(',');

  const handleInputChange = (event) => {
    if (event.target.files && event.target.files[0]) {
      onFileChange(event.target.files[0]);
    } else {
      onFileChange(null); // Ensure null is passed if no file is selected
    }
     // Reset the input value to allow re-selection of the same file
    event.target.value = null;
  };

  const handleButtonClick = () => {
    document.getElementById(`file-input-${buttonText.replace(/\s+/g, '-').toLowerCase()}`)?.click();
  };
  
  return (
    <div className="w-full">
      <input
        type="file"
        id={`file-input-${buttonText.replace(/\s+/g, '-').toLowerCase()}`}
        className="sr-only"
        accept={acceptString}
        onChange={handleInputChange}
      />
      <Button 
        type="button" 
        variant="outline" 
        className="w-full justify-start text-left font-normal text-neutral-700 border-tan-dark hover:bg-tan-dark/20"
        onClick={handleButtonClick}
      >
        {buttonIcon ? React.cloneElement(buttonIcon, { className: cn(buttonIcon.props.className, "mr-2") }) : <UploadCloud size={18} className="mr-2 text-neutral-600" />}
        {currentFile ? currentFile.name : buttonText}
      </Button>
      {fileTypeDescription && (
        <p className="text-xs text-neutral-500 mt-1.5">{fileTypeDescription}</p>
      )}
    </div>
  );
};

export default FileInput;