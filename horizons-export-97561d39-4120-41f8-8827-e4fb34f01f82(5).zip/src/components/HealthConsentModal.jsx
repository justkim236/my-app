import React from 'react';
import { Button } from '@/components/ui/button';
import { ShieldCheck, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

const HealthConsentModal = ({ onAgree }) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.3 }}
      className="fixed inset-0 bg-tan-dark/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
    >
      <Card className="w-full max-w-lg bg-tan-light shadow-2xl border-tan-darker">
        <CardHeader className="text-center">
          <motion.div 
            className="mx-auto mb-4 text-brand-primary"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: 'spring', stiffness: 150}}
          >
            <ShieldCheck size={64} />
          </motion.div>
          <CardTitle className="text-2xl font-bold text-brand-secondary">Health & Safety Agreement</CardTitle>
          <CardDescription className="text-neutral-600">
            Your well-being is important. Please read and agree to continue.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 text-sm text-neutral-700 custom-scrollbar max-h-[50vh] overflow-y-auto p-6">
          <p>
            Welcome to Own Your Pace! Before you begin, please acknowledge the following:
          </p>
          <div className="p-3 bg-tan/50 border border-tan-dark rounded-md space-y-2">
            <div className="flex items-start">
              <AlertTriangle className="h-5 w-5 text-amber-600 mr-2 mt-0.5 shrink-0" />
              <p>
                <strong>Consult a Professional:</strong> The information and exercises provided in this application are for general informational purposes only and do not constitute medical advice. Always consult with a qualified healthcare provider or fitness professional before starting any new exercise program or making changes to your existing routine, especially if you have any pre-existing health conditions or concerns.
              </p>
            </div>
            <div className="flex items-start">
              <AlertTriangle className="h-5 w-5 text-amber-600 mr-2 mt-0.5 shrink-0" />
              <p>
                <strong>Assumption of Risk:</strong> By using this application, you acknowledge that you are voluntarily participating in physical activity and assume all risks of injury that may result from such participation. Listen to your body and stop if you feel pain or discomfort.
              </p>
            </div>
             <div className="flex items-start">
              <AlertTriangle className="h-5 w-5 text-amber-600 mr-2 mt-0.5 shrink-0" />
              <p>
                <strong>Accuracy of Information:</strong> While we strive to provide accurate and up-to-date information, we make no warranties regarding the completeness, reliability, or accuracy of the content. Exercise descriptions, formulas, and other educational materials are for guidance and should be adapted to your personal fitness level and capabilities.
              </p>
            </div>
            <div className="flex items-start">
              <AlertTriangle className="h-5 w-5 text-amber-600 mr-2 mt-0.5 shrink-0" />
              <p>
                <strong>No Liability:</strong> The creators and providers of this application shall not be held liable for any direct, indirect, incidental, special, or consequential damages arising out of or in any way connected with your use of or inability to use this application or its content.
              </p>
            </div>
          </div>
          <p className="font-semibold text-brand-secondary">
            By clicking "Agree & Continue", you confirm that you have read, understood, and agree to these terms.
          </p>
        </CardContent>
        <CardFooter>
          <Button 
            onClick={onAgree} 
            className="w-full bg-brand-primary hover:bg-brand-primary/90 text-primary-foreground font-semibold py-3 text-lg"
            size="lg"
          >
            Agree & Continue
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default HealthConsentModal;