import React, { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { Film, Link2, PlusCircle } from 'lucide-react';

const ExerciseVideoSection = ({ onSubmit }) => {
  const { toast } = useToast();
  const [videoName, setVideoName] = useState('');
  const [videoUrl, setVideoUrl] = useState('');

  const resetForm = useCallback(() => {
    setVideoName('');
    setVideoUrl('');
  }, []);

  const isValidUrl = (urlString) => {
    try {
      new URL(urlString);
      return true;
    } catch (e) {
      return false;
    }
  };

  const handleVideoSubmit = (e) => {
    e.preventDefault();
    if (!videoName.trim()) {
      toast({ title: "Missing Name", description: "Please provide a name for the exercise video.", variant: "destructive" });
      return;
    }
    if (!videoUrl.trim()) {
      toast({ title: "Missing URL", description: "Please provide a URL for the exercise video.", variant: "destructive" });
      return;
    }
    if (!isValidUrl(videoUrl)) {
      toast({ title: "Invalid URL", description: "Please enter a valid video URL (e.g., starting with http:// or https://).", variant: "destructive" });
      return;
    }

    onSubmit(
      "Exercise Video Added!",
      "Your exercise video URL has been saved locally.",
      "exerciseVideoEntries",
      { 
        id: Date.now().toString(), 
        videoName, 
        videoUrl: videoUrl.trim(), // Store the URL
        timestamp: new Date().toISOString() 
      },
      resetForm
    );
  };
  
  return (
    <motion.section 
      className="bg-tan-light/70 backdrop-blur-md rounded-xl p-6 shadow-xl border border-tan-dark"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0, duration: 0.5 }}
    >
      <div className="flex items-center text-brand-accent mb-4">
        <Film size={28} className="mr-3"/>
        <h2 className="text-2xl font-bold text-brand-secondary">Add Exercise Video URL</h2>
      </div>
      <form onSubmit={handleVideoSubmit} className="space-y-6">
        <div>
          <label htmlFor="video-name" className="block mb-1 text-sm font-medium text-neutral-700">Exercise Name:</label>
          <input 
            type="text"
            id="video-name"
            value={videoName}
            onChange={(e) => setVideoName(e.target.value)}
            className="border border-tan-dark bg-white text-neutral-800 rounded-md p-2 w-full focus:ring-brand-primary focus:border-brand-primary"
            placeholder="e.g., Advanced Burpees Routine"
            required
          />
        </div>
        <div>
          <label htmlFor="video-url" className="block mb-1 text-sm font-medium text-neutral-700">Video URL:</label>
          <div className="relative">
            <Link2 className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-neutral-400" />
            <input 
              type="url"
              id="video-url"
              value={videoUrl}
              onChange={(e) => setVideoUrl(e.target.value)}
              className="border border-tan-dark bg-white text-neutral-800 rounded-md p-2 pl-10 w-full focus:ring-brand-primary focus:border-brand-primary"
              placeholder="e.g., https://example.com/video.mp4 or YouTube link"
              required
            />
          </div>
           <p className="text-xs text-neutral-500 mt-1">Enter the full URL of the video.</p>
        </div>
        <Button type="submit" variant="secondary" className="w-full bg-brand-accent hover:bg-brand-accent/90 text-accent-foreground font-semibold">
          <PlusCircle size={20} className="mr-2"/> Add Video URL
        </Button>
      </form>
    </motion.section>
  );
};

export default ExerciseVideoSection;