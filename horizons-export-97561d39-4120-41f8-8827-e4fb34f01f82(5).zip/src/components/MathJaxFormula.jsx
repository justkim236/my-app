import React, { useEffect, useRef } from 'react';

const MathJaxFormula = ({ latex }) => {
  const ref = useRef(null);

  useEffect(() => {
    if (ref.current && window.MathJax && typeof window.MathJax.typesetPromise === 'function') {
      // Ensure MathJax processes only the new content or re-processes the specific element
      // Clear previous content if MathJax doesn't handle it well on re-render, though usually it should
      // ref.current.innerHTML = ''; // Usually not needed
      // const math = document.createTextNode(`$${latex}$`);
      // ref.current.appendChild(math);
      // window.MathJax.typesetPromise([ref.current])
      //   .catch((err) => console.error('MathJax typesetting error:', err));
      
      // More direct approach: set innerHTML and typeset.
      // Ensure the LaTeX string is properly delimited for MathJax.
      // Standard delimiters are \(...\) for inline and \[...\] or $$...$$ for display.
      // If your input 'latex' does not include delimiters, add them.
      let processedLatex = latex;
      if (!latex.startsWith('$') && !latex.startsWith('\\(') && !latex.startsWith('\\[')) {
        processedLatex = `$$${latex}$$`; // Default to display math
      }
      ref.current.innerHTML = processedLatex;

      window.MathJax.typesetPromise([ref.current])
        .catch((err) => console.error('MathJax typesetting error:', err));

    } else if (ref.current && (!window.MathJax || typeof window.MathJax.typesetPromise !== 'function')) {
      console.warn('MathJax or MathJax.typesetPromise not available. Cannot render LaTeX.');
      ref.current.innerText = `LaTeX (Preview not available): ${latex}`;
    }
  }, [latex]); // Re-run when latex content changes

  if (!latex || typeof latex !== 'string' || latex.trim() === '') {
    return null; // Don't render anything if latex is empty
  }

  // The div will be filled by the useEffect hook.
  // Add overflow-x-auto for cases where formula is too wide.
  return (
    <div className="my-2 p-2 border border-dashed border-amber-500 rounded bg-amber-50/50 overflow-x-auto">
      <div ref={ref}></div>
    </div>
  );
};

export default MathJaxFormula;