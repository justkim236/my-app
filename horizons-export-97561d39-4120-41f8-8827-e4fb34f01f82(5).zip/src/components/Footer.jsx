import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-tan-light/50 backdrop-blur-md text-brand-secondary text-center py-6 mt-12 shadow-inner border-t border-tan-dark">
      <p className="text-neutral-600 text-sm">&copy; {new Date().getFullYear()} Own Your Pace. All rights reserved.</p>
      <p className="text-xs text-neutral-500">Empowering you on your journey of self-improvement.</p>
    </footer>
  );
};

export default Footer;